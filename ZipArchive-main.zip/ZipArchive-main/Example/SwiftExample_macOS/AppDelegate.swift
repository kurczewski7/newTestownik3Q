//
//  AppDelegate.swift
//  SwiftExample_macOS
//
//  Created by Antoine Cœur on 2019/4/26.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

}

